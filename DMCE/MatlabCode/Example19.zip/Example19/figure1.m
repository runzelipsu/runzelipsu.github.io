figure(1)
fig1ab2;
fig1gh;
figure(2)
fig1cd
fig1ef