function y=func2(x,eps);
y=16*(x-0.5).*(x-0.5)+eps;
