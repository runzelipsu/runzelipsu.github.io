function y=func1(x,eps);
y=4*sin(2*pi*x)+eps;