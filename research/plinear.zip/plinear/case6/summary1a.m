

load('ex1bls.m')
load('ex1sls.m')

load('ex1mulow.m') 
load('ex1muup.m') 
beta=[0,2,1,0,0,0,1.5,0]';

d=length(beta);

for i=1:d
  for j=1:d
     S(i,j)=0.5^(abs(i-j));
  end;
end;

K=1000;

 

b0=[0,2,1,0,0,0,1.5,0];

n=400;

a=sort(ex1bls);
b=a(25,:);
c=a(975,:);
d=[b(2),c(2),0,b(3),c(3),0,b(7),c(7),0];

critval=tinv(0.975,n-8);
t1=ex1bls-critval*ex1sls;
t2=ex1bls+critval*ex1sls;
t3 = ones(length(ex1bls),1)*b0;
p1 = mean((t1<=t3).*(t3<=t2));

e=[mean(t1)',mean(t2)',p1'];
cisw=[e(2,:),e(3,:),e(7,:)];

f=ex1mulow;
g=ex1muup;
p2 = mean((f<=t3).*(t3<=g));

h=[mean(f)',mean(g)',p2'];
ciel = [h(2,:),h(3,:),h(7,:)];
out=[d;cisw;ciel]
 


 
