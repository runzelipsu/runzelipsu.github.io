n=200;
nsim=1000;
sigcase=1;


sigma=1;
beta=[0,2,1,0,0,0,1.5,0];
bne0=(beta~=0);
p=length(beta);
 
for i=1:p
  for j=1:p
     S(i,j)=0.5^(abs(i-j));
  end;
end;

S=S^(0.5);

sig_U=zeros(p,p);
sig_U(1:5,1:5)=0.6*(0.2*ones(5,5)+0.8*eye(5));
sig_U=sig_U^(0.5);

rand('seed',1001)
randn('seed',1001)

%z=(0:1/(n-1):1)';

bls=[];
sls=[];
bscad=[];
sscad=[];
bl1=[];
sl1=[];
baic=[];
saic=[];
bbic=[];
sbic=[];
bric=[];
sric=[];
bphi=[];
sphi=[];
bora=[];
sora=[];



for k=1:nsim
   z=rand(n,1);
	gz=2*(sin(2*pi.*z.^3));
   x=randn(n,p)*S;
	U1=randn(n,p)*sig_U;
	U2=randn(n,p)*sig_U;
	w=x+(U1+U2)/2;
	sig_W=0.25*(U1-U2)'*(U1-U2)/n;
				%sig_W=cov(U);  %The estimated covariance matrix of U
   
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Two different error choices
if sigcase==1
	err=randn(n,1)*sigma;
elseif sigcase==2
	err=0.15*randn(n,1).*(0.2*z+sin(2*pi*(x*beta').^2)).*(chi2rnd(2,n,1)-2);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% generate data on a basis of case speficied above
y=x*beta'+gz+err;
y_z=lpolyreg(z,y,1);
for i=1:p
     w_z(:,i)=lpolyreg(z,w(:,i),1);
end

for i=1:p
     x_z(:,i)=lpolyreg(z,x(:,i),1);
end
x_new=x-x_z;
w_new=w-w_z;
y_new=y-y_z;

beta0=inv(w_new'*w_new-n*sig_W)*w_new'*y_new;
 
 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%CI based on Empirical Likelihood             %
% 05/06/04
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
yy=y_new*ones(1,p);
w_new_arg=w_new.*yy;
arg2=w_new'*w_new-n*sig_W;
if sum(eig(arg2)>0)<p
   arg2=w_new'*w_new;
end

for si=1:n
z_arg(si,:)=((w_new(si,:)'*w_new(si,:)-sig_W)*beta')';
end
arg=w_new_arg-z_arg;

for s=1:p
   args=arg(:,s);
   low(s,1)=el_ci_hua(args,min(args)-0.001,p,0.1);
   up(s,1)=el_ci_hua(args,max(args)+0.001,p,0.1);
end;
mu.low(k,:)=(inv(arg2)*(w_new'*y_new-n*up))';
mu.up(k,:)=(inv(arg2)*(w_new'*y_new-n*low))';
%CI=[mu.low,beta',mu.up]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%arg2=w_new'*w_new-n*sig_W/2;
%if sum(eig(arg2)>0)<p
%   arg2=w_new'*w_new;
%end;
	w=w_new;
   y=y_new;
   x=x_new;
   
   w0=w(:,[2,3,7]);
	bora0=inv(w0'*w0-n*sig_W([2,3,7],[2,3,7]))*w0'*y;
	r = y-w0*bora0;
	std_ora0 = sqrt(diag(inv(w0'*w0-n*sig_W([2,3,7],[2,3,7]))*w0'*diag(r.^2)*w0*inv(w0'*w0-n*sig_W([2,3,7],[2,3,7]))));

   borc=zeros(p,1);
   std_orc=zeros(p,1);
   borc([2,3,7])=bora0;
   std_orc([2,3,7])=std_ora0;
   bora=[bora,borc];
   sora=[sora,std_orc];

   
 
	beta_int=inv(w'*w-n*sig_W)*w'*y;
	r = y-w*beta_int;
	std_ini = sqrt(diag(inv(w'*w-n*sig_W)*w'*diag(r.^2)*w*inv(w'*w-n*sig_W)));

	% Ls estimator
	bls=[bls,beta_int];
	sls=[sls,std_ini];
 
	% SCAD 1 
	lambda=gcvscadmem(beta_int,std_ini, w,y,sig_W);
	[temp1,temp2]=scadmem(beta_int,std_ini,lambda,w,y,sig_W);
   bscad=[bscad,temp1];
   sscad=[sscad,temp2];
   
	%L1-penality function
	lambda=gcvlassomem(beta_int,std_ini, w,y,sig_W);
   [temp1,temp2]=lassomem(beta_int,std_ini,lambda,w,y,sig_W);
   bl1=[bl1,temp1];
   sl1=[sl1,temp2];
    
	% Best subset
	[t11,t12,t21,t22,t31,t32,t41,t42]=bestsubmem(w,y,sig_W);
   baic=[baic,t11];
   saic=[saic,t12];
   bbic=[bbic,t21];
   sbic=[sbic,t22];
   bric=[bric,t31];
   sric=[sric,t32];
   bphi=[bphi,t41];
   sphi=[sphi,t42];   

end % end for loop "k"

fid=fopen('ex1mulow.m','w');
fprintf(fid,'%7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f\n', mu.low');
fclose(fid)

fid=fopen('ex1muup.m','w');
fprintf(fid,'%7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f\n', mu.up');
fclose(fid)

fid=fopen('ex1elci.m','w');
fprintf(fid,'%7.4f %7.4f %7.4f\n', el_ci');
fclose(fid)




fid=fopen('ex1bls.m','w');
fprintf(fid,'%7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f\n', bls);
fclose(fid)

fid=fopen('ex1sls.m','w');
fprintf(fid,'%7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f\n', sls);
fclose(fid)

fid=fopen('ex1bscad.m','w');
fprintf(fid,'%7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f\n', bscad);
fclose(fid)

fid=fopen('ex1sscad.m','w');
fprintf(fid,'%7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f\n', sscad);
fclose(fid)

fid=fopen('ex1blasso.m','w');
fprintf(fid,'%7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f\n', bl1);
fclose(fid)

fid=fopen('ex1slasso.m','w');
fprintf(fid,'%7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f\n', sl1);
fclose(fid)

fid=fopen('ex1baic.m','w');
fprintf(fid,'%7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f\n', baic);
fclose(fid)

fid=fopen('ex1saic.m','w');
fprintf(fid,'%7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f\n', saic);
fclose(fid)

fid=fopen('ex1bbic.m','w');
fprintf(fid,'%7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f\n', bbic);
fclose(fid)

fid=fopen('ex1sbic.m','w');
fprintf(fid,'%7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f\n', sbic);
fclose(fid)

fid=fopen('ex1bric.m','w');
fprintf(fid,'%7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f\n', bric);
fclose(fid)

fid=fopen('ex1sric.m','w');
fprintf(fid,'%7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f\n', sric);
fclose(fid)


fid=fopen('ex1bora.m','w');
fprintf(fid,'%7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f\n', bora);
fclose(fid)

fid=fopen('ex1sora.m','w');
fprintf(fid,'%7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f\n', sora);
fclose(fid)
