

load('ex1bls.m')
load('ex1blasso.m')
load('ex1bora.m')
load('ex1bscad.m')
load('ex1baic.m')
load('ex1bbic.m')
load('ex1bric.m')
 




load('ex1sls.m')
load('ex1slasso.m')
load('ex1sora.m')
load('ex1sscad.m')
load('ex1saic.m')
load('ex1sbic.m')
load('ex1sric.m')

beta=[0,2,1,0,0,0,1.5,0]';

d=length(beta);

for i=1:d
  for j=1:d
     S(i,j)=0.5^(abs(i-j));
  end;
end;

K=1000;

me=zeros(K,7);

me(:,1)=diag((ex1bls-ones(K,1)*beta')*S*(ex1bls-ones(K,1)*beta')');

me(:,3)=diag((ex1blasso-ones(K,1)*beta')*S*(ex1blasso-ones(K,1)*beta')');

me(:,7)=diag((ex1bora-ones(K,1)*beta')*S*(ex1bora-ones(K,1)*beta')');

me(:,2)=diag((ex1bscad-ones(K,1)*beta')*S*(ex1bscad-ones(K,1)*beta')');

me(:,4)=diag((ex1baic-ones(K,1)*beta')*S*(ex1baic-ones(K,1)*beta')');

me(:,5)=diag((ex1bbic-ones(K,1)*beta')*S*(ex1bbic-ones(K,1)*beta')');

me(:,6)=diag((ex1bric-ones(K,1)*beta')*S*(ex1bric-ones(K,1)*beta')');


rme = me(:,2:7)./(me(:,1)*ones(1,6));

mrme=nanmedian(rme);
srme=nanstd(rme);

 
 
 ze=[sum(mean(ex1bscad(:,beta==0)==0)), sum(mean(ex1bscad(:,beta~=0)==0));...
    sum(mean(ex1blasso(:,beta==0)==0)), sum(mean(ex1blasso(:,beta~=0)==0));...
      sum(mean(ex1baic(:,beta==0)==0)),sum(mean(ex1baic(:,beta~=0)==0));...
      sum(mean(ex1bbic(:,beta==0)==0)),sum(mean(ex1bbic(:,beta~=0)==0));...
      sum(mean(ex1bric(:,beta==0)==0)),sum(mean(ex1bric(:,beta~=0)==0));...
         5,0];

out1=[mrme',srme',ze];

b0=[0,2,1,0,0,0,1.5,0];


critval=tinv(0.975,100-8);
t1=ex1blasso-critval*ex1slasso;
t2=ex1blasso+critval*ex1slasso;
t3 = ones(length(ex1blasso),1)*b0;
p1 = mean((t1<=t3).*(t3<=t2));

t1=ex1bscad-critval*ex1sscad;
t2=ex1bscad+critval*ex1sscad;
t3 = ones(length(ex1bscad),1)*b0;
p2 = mean((t1<=t3).*(t3<=t2));

t1=ex1bora-critval*ex1sora;
t2=ex1bora+critval*ex1sora;
t3 = ones(length(ex1bora),1)*b0;
p3 = mean((t1<=t3).*(t3<=t2));



se=[std(ex1blasso(:,2)), mean(ex1slasso(:,2)), std(ex1slasso(:,2)),...
      std(ex1blasso(:,3)), mean(ex1slasso(:,3)), std(ex1slasso(:,3)),...
      std(ex1blasso(:,7)), mean(ex1slasso(:,7)), std(ex1slasso(:,7));...
std(ex1bscad(:,2)), mean(ex1sscad(:,2)), std(ex1sscad(:,2)),...
      std(ex1bscad(:,3)), mean(ex1sscad(:,3)), std(ex1sscad(:,3)),...
      std(ex1bscad(:,7)), mean(ex1sscad(:,7)), std(ex1sscad(:,7));...      
std(ex1bora(:,2)), mean(ex1sora(:,2)), std(ex1sora(:,2)),...
      std(ex1bora(:,3)), mean(ex1sora(:,3)), std(ex1sora(:,3)),...
      std(ex1bora(:,7)), mean(ex1sora(:,7)), std(ex1sora(:,7))]           

 