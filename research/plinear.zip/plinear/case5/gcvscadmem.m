function [lambda_sel,gcv]=gcvscadmem(beta_int,std_ini,x,y,sigW);
% [lambda_sel,gcv]=gcvscada(data) is used to selected
% the thresholding parameter lambda  for new thresholding with
% a=2+sqrt(3) considered in Fan and Li (1999). 
% Variable selection via Penalized likelihood.
%
% Input: data -- the data matrix arranged in the format [x,y];
%
% Output: lambda_sel -- the selected parameter lambda,
%          gcv -- the generalized cross-validation statistics
a=3.7;
n=length(y);
t1=sqrt(2);
t2=sqrt(log(n));
l0=logspace(log10(t1),log10(t2),20)/2;

for k=1:length(l0);
    lambda=l0(k);
   [beta,beta_std,effno,rss]=scadmem(beta_int,std_ini,lambda,x,y,sigW);
    gcv(k,1)=rss/(1-effno/n)/(1-effno/n)/n;
end;
[med,medi]=min(gcv);
lambda_sel=l0(medi(1)); 

