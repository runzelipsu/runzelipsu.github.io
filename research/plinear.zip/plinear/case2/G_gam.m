function [wi,G_gam]=G_gam(x,gam,r0);
%
% Input: x -- vector of obserbation;
%	   gam -- parameter
%
% Output: 
%	 G_gam

arg1=1./(x-gam);
deno=sum(arg1);
wi=arg1/deno;
G_gam=sum(log(length(x)*wi))-log(r0);
