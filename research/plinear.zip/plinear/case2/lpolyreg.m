function [yhat,h,variance]=lpolyreg(x,y,p)

% This function computes the local polynomial fit of degree p for
%
%             y = m(x) + iid errors.
%
% It implements the DPI bandwidth selection method of Ruppert, Sheather
% and Wand (Journal of the American Statistical Association, 1995).
%
% Syntax: [yhat,h,variance]=lpolyreg(x,y,p)
%
% Inputs:  x   vector of covariates (nx1)
%          y   vector of observations (nx1)
%          p   order of local polynomials (scalar)
%
% Outputs: yhat      vector fits at the observation points (nx1)
%          h         bandwidths for the D additive functions (scalar)
%          variance  estimated variance of the errors (scalar)
%
% NOTE: p HAS TO BE ODD FOR THE BANDWIDTH SELECTION TO BE VALID!
%
% Calls the following m-files: lpolyregh, polyreg, fact, constants
%
%                                        Last revised: 8/14/97 by JDO

% Initialization (sets the meta-parameters)

%     numbin is the number of bins into which the observations are distributed
%     for each covariate, which is used in the computation of a minimum "safe"
%     bandwidth to avoid singularity
%                                           (should normally not be adjusted)
%     marg is the inflation factor used to increase the minimum "safe"
%     bandwidth
%                                   (can be increased in case of singularity)

numbin=500;
marg=0.2;

%    Cmax is the maximum number of iterations in the search for the optimum
%    number of "pieces" for the piecewise polynomial regression
%                                           (should normally not be adjusted)
%    Nmax is the maximum number of pieces for each covariate
%                                   (can be decreased in case of singularity)
Cmax=10;
Nmax=7;
M1=100;

%    alpha is the proportion of each boundary that is ignored in the
%    computation of theta
%                               (can be increased if plot of theta displays
%                                              instability at the boundaries)

alpha=0.1;

% Compute the constants for the bandwidth estimators for local polynomial
% degree p

cst=constants(p);

% Compute the minimum "safe" bandwidths for theta (bmg), variance (bmh)
% and m (bmh)

[n,D]=size(x);
if D>1
	'*** matrix x is not one-dimensional ***'
	stop
end
numbin=n*(n<=numbin)+numbin*(n>numbin);
Nmax= max(min(fix(n/(D*20)),Nmax),1);
ybar=sum(y)/n;
rx=max(x)-min(x);
xc=(min(x)+max(x))/2;
xgridm=linspace(xc-1.01*rx/2,xc+1.01*rx/2,M1)';

bmg=0;
bmh=0;

[nn,xx]=hist(x,numbin);
xx=xx(find(nn~=0))';
nn=max(size(xx));
temp=sort(xx(1:nn-p-3)-xx(p+4:nn));
bmg=-temp(1)*(1+marg);
temp=sort(xx(1:nn-p-1)-xx(p+2:nn));
bmh=-temp(1)*(1+marg);

% Find initial values of sigma2 and theta13 by piecewise polynomial
% regression of degree p+3

pp=[];
xx=[];
for j=1:Nmax
	tempo=zeros(n,1);
	eval(['xx',int2str(j),'=[];'])
	eval(['pp',int2str(j),'=[];'])
	for jj=1:j
		temp=(x <= min(x)+jj/j*rx);
		eval(['xx',int2str(j),'=[xx',int2str(j),' x.*(temp-tempo)];'])
		tempo=temp;
		eval(['pp',int2str(j),'=[pp',int2str(j),' p];'])
	end
end

rs=zeros(1,Nmax);
for j=1:Nmax
	eval(['yhat=polyreg(y,xx',int2str(j),',pp',int2str(j),'+3);'])
	rs(j)=sum((yhat-y).^2);
end
df=(p+3)*linspace(1,Nmax,Nmax);
Cp=rs/n+2*(1+df)/n*rs(Nmax)/(n-1-df(Nmax));
[Cpmin,jmin]=min(Cp);
eval(['xx=xx',int2str(jmin),';'])
eval(['pp=pp',int2str(jmin),';'])
[yhat,beta]=polyreg(y,xx,pp+3);
df=max(size(beta))-1;
residP=y-yhat;
sigma2P=sum(residP.^2)/(n-1-df);

mstart=zeros(size(x));
theta1=zeros(size(x));
theta3=zeros(size(x));
beta(1)=[];
for j=1:jmin
	btemp1=beta(p+1:p+3);
	p1=fact(linspace(p+1,p+3,3)')./fact([0 1 2]');
	btemp1=btemp1.*p1;
	btemp3=beta(p+3);
	p3=fact(p+3);
	btemp3=btemp3.*p3;
	Dp=[(xx(:,1)~=0)];
	theta3=theta3+Dp*btemp3;
	Dp=[Dp xx(:,1) xx(:,1).^2];
	theta1=theta1+Dp*btemp1;
	binit=[0; beta(1:p+3)];
	for k=3:p+3
		Dp=[Dp xx(:,1).^k];
	end
	beta(1:p+3)=[];
	xx(:,1)=[];
end

theta13=sum(theta1.*theta3)/n;

% Compute theta11 through additive model with local polynomial regression
% of degree p+2

g=cst(2,:)+(cst(3,:)-cst(2,:)).*(theta13>0);
g=g.*(sigma2P*rx./abs(theta13)/n).^(1./(2*p+5));
if g<bmg
	g=bmg;
end

thet=zeros(n,D);
clip=thet;
minlim=min(x)+alpha*rx;
maxlim=max(x)-alpha*rx;
if(n>M1)
	xgrid=xgridm;
	temp=lpolyregh(xgrid,x,g,p+2,p+1)*y;
	thet=interp1(xgrid,temp,x,'cubic');
	clip=(minlim<x).*(x<maxlim);
else
	xgrid=x;
	thet=lpolyregh(xgrid,x,g,p+2,p+1)*y;
	clip=(minlim<x).*(x<maxlim);
end
thet=thet.*clip;
theta11=sum(thet(~isnan(thet)).^2)/sum(clip(~isnan(thet)));

% Compute variance

% Fit local polynomial with bandwidth hP(theta11,sigma2P) on binned data

k=cst(4,:).*(sigma2P*rx./theta11/n).^(1./(2*p+3));
if k<bmh
	k=bmh;
end

if(n>M1)
	xgrid=xgridm;
	temp=lpolyregh(xgrid,x,k,p,0)*y;
	fit=interp1(xgrid,temp,x,'cubic');
else
	xgrid=x;
	fit=lpolyregh(xgrid,x,k,p,0)*y;
end
variance=sum((y(~isnan(fit))-fit(~isnan(fit))).^2)/sum((~isnan(fit)));

% Compute additive fit with local polynomials of degree p

h=cst(1,:).*(variance*rx./theta11/n).^(1./(2*p+3));
if h<bmh
	h=bmh;
end
if(n>M1)
	xgrid=xgridm;
	temp=lpolyregh(xgrid,x,h,p,0)*y;
	yhat=interp1(xgrid,temp,x,'cubic');
else
	xgrid=x;
	yhat=lpolyregh(xgrid,x,h,p,0)*y;
end
