
function y=muk(j)

y=3*(rem(j,2)~=1)./((j+1).*(j+3));



