function a=madr(x);
% a=madr(x) is to compute the median of absolute deviation from the median.
% A robust estimate of sigma
[n,d]=size(x);
mx=nanmedian(x);
a=nanmedian(abs(x-ones(n,1)*mx))/0.6745;
