function [res]=el_ci_hua(x,gam0,p,alpha)
%inputs:
%     
%
epsilon=10^(-6);
step=0;
delta=1;
r0=exp(-chi2inv(1-alpha,p)/2);
while (delta>=epsilon)&(step<20)
   step=step+1;
   [a1,a2]=G_gam(x,gam0,r0);
 gam1=gam0-a2/G_gam_dev(x,gam0);
 delta=abs(gam1-gam0);
 gam0=gam1;
end;
[wi,a2]=G_gam(x,gam1,r0);
res=sum(wi.*x);
%[gam1,res,step,delta]



%n=200;
%x=(randn(n,1)+2)*.3;
%el_ci_hua(x,min(x)-0.1,1,0.1)
%el_ci_hua(x,max(x)+0.1,1,0.1)