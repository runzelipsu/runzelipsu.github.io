function [G_gam_d]=G_gam_dev(x,gam);
%
% Input: x -- vector of obserbation;
%	   gam -- parameter
%
% Output: 
%	 G_gam

arg1=1./(x-gam);
arg2=sum(arg1);
arg3=sum(arg1.^2);
G_gam_d=arg2-(length(x)/arg2)*arg3;
