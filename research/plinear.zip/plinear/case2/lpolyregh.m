function smoother=lpolyregh(grid,x,h,p,r)

% Computes the local polynomial smoother matrix for the rth 
% derivative of a polynomial of degree p over the set of points
% grid, given the observations x and bandwidth h
%
% Syntax: smoother=lpolyregh(grid,x,h,p,r)
%
% Uses: fact, epan

n=max(size(x));
m=max(size(grid));
smoother=zeros(m,n);
for i=1:m
xx=x-grid(i);
Dx =[ones(n,1) xx];
for j=2:p
Dx = [Dx xx.^j];
end
Wx=epan(xx/h)/h;
Wm=Wx*ones(1,p+1);
Dxx=Wm.*Dx;
mat=inv(Dx'*Dxx)*Dxx';
smoother(i,:)=fact(r)*mat(r+1,:);
end
