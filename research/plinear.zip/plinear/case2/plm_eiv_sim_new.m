n=200; 
sig=[1,2];
nsim=500;
for j=1:2
 diary plm_eiv_scad.dat
 plm_eiv_scad_new(n,sig(j),nsim);
clock
end
clear


n=500; 
sig=[1,2];
nsim=500;
for j=1:2
 diary plm_eiv_scad.dat
 plm_eiv_scad_new(n,sig(j),nsim);
clock
end

diary off