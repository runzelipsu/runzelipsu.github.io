function [baic,std_aic,bbic,std_bic,bric, std_ric,bphi,std_phi]=bestsubmem(x,y,sigW);
%[b,r]=bestsubr(data) is BEST SUBset Regression;
%inputs: data: 
%					x - x-matrix
%					y - y-vector
%					sigW - the estimated of covariance matrix of U.
%
%outputs: 
%        baic, bbic, bric, rphi: the estimated coefficients based on best subset selection
%        std_aic,std_bic,std_ric,std_phi, the standard error of estimated coefficients.
%
[n,d]=size(x);

 b0=inv(x'*x-n*sigW)*x'*y;
 mse =  sum((y-x*b0).^2)/(n-d) - b0'*sigW*b0;

for k=1:2^d
 % To find dyadic representation of k
 med=k;
 for l=1:d
  a(l)=med-2*floor(med/2);
  med=(med-a(l))/2;
 end;
 % End of find dyadic representation of k;

 x0=x(:,a==1);  % the selected subset. 
 sigW0=sigW(a==1,a==1);
 b=inv(x0'*x0-n*sigW0)*x0'*y;
 rss =  sum((y-x0*b).^2);
 
 pe_aic0=rss+sum(a)*2*mse;  % AIC score 
                          % sum(a)=p, the dimension of current x.
 if k==1
  baic=zeros(d,1);
  baic(a==1)=b;
  pe_aic=pe_aic0;
 end;
 
 if  (pe_aic>pe_aic0)&(k>1)
  baic=zeros(d,1);
  baic(a==1)=b;
  pe_aic=pe_aic0;
 end;
 
 pe_bic0= rss +sum(a)*log(n)*mse;  % BIC score 
                          % sum(a)=p, the dimension of current x.
 if k==1
  bbic=zeros(d,1);
  bbic(a==1)=b;
  pe_bic=pe_bic0;
 end;
 
 if  (pe_bic>pe_bic0)&(k>1)
  bbic=zeros(d,1);
  bbic(a==1)=b;
  pe_bic=pe_bic0;
 end;
 
pe_ric0=rss+sum(a)*2*log(d)*mse;  % RIC score 
                          % sum(a)=p, the dimension of current x.
 if k==1
  bric=zeros(d,1);
  bric(a==1)=b;
  pe_ric=pe_ric0;
 end;
 
 if  (pe_ric>pe_ric0)&(k>1)
  bric=zeros(d,1);
  bric(a==1)=b;
  pe_ric=pe_ric0;
 end;

pe_phi0=rss+sum(a)*log(log(n))*mse;  % Phi score 
                          % sum(a)=p, the dimension of current x.
 if k==1
  bphi=zeros(d,1);
  bphi(a==1)=b;
  pe_phi=pe_phi0;
 end;
 
 if  (pe_phi>pe_phi0)&(k>1)
  bphi=zeros(d,1);
  bphi(a==1)=b;
  pe_phi=pe_phi0;
 end;


end; 

%%% Compute standard error
  a=(baic~=0);
  b=baic(a==1);
  x0=x(:,a==1);
  sigW0=sigW(a==1,a==1);
  r=y-x0*b;
  t1=inv(x0'*x0-n*sigW0);
  t2=x0'*diag(r.^2)*x0*n/(n-sum(a));
  std0=sqrt(diag(t1*t2*t1));
  std_aic=zeros(d,1);
  std_aic(a==1)=std0;
  
  a=(bbic~=0);
  b=bbic(a==1);
  x0=x(:,a==1);
  sigW0=sigW(a==1,a==1);
  r=y-x0*b;
  t1=inv(x0'*x0-n*sigW0);
  t2=x0'*diag(r.^2)*x0*n/(n-sum(a));
  std0=sqrt(diag(t1*t2*t1));
  std_bic=zeros(d,1);
  std_bic(a==1)=std0;
  
  a=(bric~=0);
  b=bric(a==1);
  x0=x(:,a==1);
  sigW0=sigW(a==1,a==1);
  r=y-x0*b;
  t1=inv(x0'*x0-n*sigW0);
  t2=x0'*diag(r.^2)*x0*n/(n-sum(a));
  std0=sqrt(diag(t1*t2*t1));
  std_ric=zeros(d,1);
  std_ric(a==1)=std0;
  
  a=(bphi~=0);
  b=bphi(a==1);
  x0=x(:,a==1);
 sigW0=sigW(a==1,a==1);
  r=y-x0*b;
  t1=inv(x0'*x0-n*sigW0);
  t2=x0'*diag(r.^2)*x0*n/(n-sum(a));
  std0=sqrt(diag(t1*t2*t1));
   std_phi=zeros(d,1);
  std_phi(a==1)=std0;
 
 