
function y=rk(j)

y=9*(rem(j,2)~=1)./((j+1).*(j+3).*(j+5));


