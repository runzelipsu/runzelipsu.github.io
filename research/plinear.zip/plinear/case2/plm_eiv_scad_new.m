function[el_ci,result]=plm_eiv_scad_new(n,sigcase,nsim);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function for plm_eiv paper on variable selection
% modiefief from ex6.m given by Runzi 
%input:	n-- sample size
%		sigcase-- 1 or 0.2z+sin(2*pi*x^2), or 0.25*(chi-squared_2-2)
%		nsim----- replication times
%Output:
%		SCAD^1, SCAD^2, BIC, LASSO, HARD
%		mrme--- median relative model error
%		ave.zero--- 
%		est--- average estimated values based on nsim replicaltions
%		std--- standard error
%
%
%
%		Hua Liang
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sigma=1;
beta=[0,1.5,0.25,0,0,0,0.7,0];
bne0=(beta~=0);
p=length(beta);
 
for i=1:p
  for j=1:p
     S(i,j)=0.5^(abs(i-j));
  end;
end;

z=(0:1/(n-1):1)';
gz=2*(sin(2*pi.*z.^3));

for k=1:nsim

x=randn(n,p)*S^0.5;

sig_U=zeros(p,p);
sig_U(1:5,1:5)=0.6*(0.2*ones(5,5)+0.8*eye(5));
U=randn(n,p)*sig_U;

sig_W=cov(U);
w=x+U;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Two different error choices
if sigcase==1
	err=randn(n,1)*sigma;
elseif sigcase==2
	err=0.15*randn(n,1).*(0.2*z+sin(2*pi*(x*beta').^2)).*(chi2rnd(2,n,1)-2);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% generate data on a basis of case speficied above
y=x*beta'+gz+err;
y_z=lpolyreg(z,y,1);
for i=1:p
     w_z(:,i)=lpolyreg(z,w(:,i),1);
end

for i=1:p
     x_z(:,i)=lpolyreg(z,x(:,i),1);
end
x_new=x-x_z;
w_new=w-w_z;
y_new=y-y_z;

ratio_x_w=var(x)./var(w);
ratio_xtilde_wtilde=var(x_new)./var(w_new);
b_theory_se=diag(sqrtm(inv(cov(x_new))).*sigma);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%CI based on Empirical Likelihood             %
% 05/05/04
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%yy=y_new*ones(1,p);
%w_new_arg=w_new.*yy;
%arg2=w_new'*w_new-n*sig_W;
%if sum(eig(arg2)>0)<p
%   arg2=w_new'*w_new;
%end
%w_new1=w_new_arg*inv(arg2/n);
%
%for s=1:p
%   w_new1s=w_new1(:,s);
%   low(k,s)=el_ci_hua(w_new1s,min(w_new1s)-0.001,p,0.1);
%   up(k,s)=el_ci_hua(w_new1s,max(w_new1s)+0.001,p,0.1);
%end;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%CI based on Empirical Likelihood             %
% 05/06/04
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
yy=y_new*ones(1,p);
w_new_arg=w_new.*yy;
arg2=w_new'*w_new-n*sig_W;
if sum(eig(arg2)>0)<p
   arg2=w_new'*w_new;
end

for si=1:n
z_arg(si,:)=((w_new(si,:)'*w_new(si,:)-sig_W)*beta')';
end
arg=w_new_arg-z_arg;

for s=1:p
   args=arg(:,s);
   low(s,1)=el_ci_hua(args,min(args)-0.001,p,0.1);
   up(s,1)=el_ci_hua(args,max(args)+0.001,p,0.1);
end;
mu.low(k,:)=(inv(arg2)*(w_new'*y_new-n*up))';
mu.up(k,:)=(inv(arg2)*(w_new'*y_new-n*low))';
%CI=[mu.low,beta',mu.up]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
arg2=w_new'*w_new-n*sig_W/2;
if sum(eig(arg2)>0)<p
   arg2=w_new'*w_new;
end
beta_int=inv(arg2)*(w_new'*y_new);

data=[w_new,y_new];
b_naive(k,:)=beta_int';

% SCAD 1 
[lambda,a]=gcv_g(data,sig_W); 
[temp1,temp2]=lasso_g(beta_int,lambda,a,data,sig_W);
b_scad1(k,:)=temp1';
std_scad1(k,:)=temp2';

% SCAD 2
lambda=gcv_n(data,sig_W); 
[temp1,temp2]=lasson_g(beta_int,lambda,data,sig_W);
b_scad2(k,:)=temp1';
std_scad2(k,:)=temp2';

% BIC
[temp1,temp2]=bestsub(data,sig_W);
b_bic(k,:)=temp1';
std_bic(k,:)=temp2';

%L1(soft thresholding) penality function
lambda=gcv_l(data,sig_W); 
[temp1,temp2]=lasso(beta_int,lambda,data,sig_W);
b_soft(k,:)=temp1';
std_soft(k,:)=temp2';

%Hard thresholding penality function
lambda=gcv_h(data,sig_W); 
[temp1,temp2]=lasso_h(beta_int,lambda,data,sig_W);
b_hard(k,:)=temp1';
std_hard(k,:)=temp2';

end % end for loop "k"

el_ci=[mean(mu.low)' beta' mean(mu.up)']


allbeta=[beta',(mean(b_naive))',(mean(b_scad1))',(mean(b_scad2))',(mean(b_bic))',(mean(b_soft))',(mean(b_hard))'];

a=b_naive-ones(nsim,1)*beta;
zz(:,1)=sum((abs(b_naive)==0)')';
mse(:,1)=diag(a*S*a');

a=b_scad1-ones(nsim,1)*beta;
zz(:,2)=sum((abs(b_scad1)==0)')';
mse(:,2)=diag(a*S*a');
 
a=b_scad2-ones(nsim,1)*beta;
zz(:,3)=sum((abs(b_scad2)==0)')';
mse(:,3)=diag(a*S*a');

a=b_bic-ones(nsim,1)*beta;
zz(:,4)=sum((abs(b_bic)==0)')';
mse(:,4)=diag(a*S*a');

a=b_soft-ones(nsim,1)*beta;
zz(:,5)=sum((abs(b_soft)==0)')';
mse(:,5)=diag(a*S*a');
 
a=b_hard-ones(nsim,1)*beta;
zz(:,6)=sum((abs(b_hard)==0)')';
mse(:,6)=diag(a*S*a');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
mse_med=median(mse);
mrme=(mse_med(:,[2:6])/mse_med(1))';
ave.zero=(mean(zz))';
est_all=[mean(b_scad1)',mean(b_scad2)',mean(b_bic)',mean(b_soft)',mean(b_hard)']';
std_all=[mean(std_scad1)',mean(std_scad2)',mean(std_bic)',mean(std_soft)',mean(std_hard)']';
est=est_all(:,bne0);
std=std_all(:,bne0);
result=[mrme,ave.zero([2:6],:),est,std]