function [beta,beta_std,effno,rss]=scadmem(beta_int,std_ini,lambda0,x,y,sigW)
% [beta,beta_std,effno,rss]=scadmem(beta_int,std_ini,lambda0,x,y,sigW) is to calculate
% penalized least squares with SCAD penalty for measurement error data, 
% using Hunter and Li's algorithm with
% different regularization parameters for different coefficients.
%
%inputs:
%       beta_int: initial value of beta, a d-column vector;
%		  std_ini: standard deviation of beta_int       
%       lambda0: a tuning parameter.
%       x:  indep. variable
%       y: response
%		  sigW: the estimated covariance matrix of U.
%
%Outputs: 
%		beta: estimated coefficient
%		beta_std: standard error of beta
%     effno: degrees of freedom
%     rss: residual sum of squares
%
a=3.7;
[n,d]=size(x);
tau =10^(-5);
sigW=n*sigW;

tv = beta_int./std_ini;
abeta = abs(beta_int);
xmin = min(abeta(tv>0.1));


lambda=lambda0*std_ini;
epsr = tau*xmin/2/n./lambda;


delta=2;
step=0;
beta=zeros(d,1);
while (delta>=tau/2)&(step<500)
 step=step+1;
 abeta=abs(beta_int);
 pbeta0=(abeta<=lambda)+((a*lambda-abeta)./((a-1)*lambda)).*((abeta>lambda).*(abeta<a*lambda));
 beta=(x'*x-sigW+n*diag((lambda.*pbeta0)./(abeta+epsr)))^(-1)*x'*y;
 abeta=abs(beta);
 pbeta0=(abeta<=lambda)+((a*lambda-abeta)./((a-1)*lambda)).*((abeta>lambda).*(abeta<a*lambda));
 delta = max(abs(x'*(x*beta-y) - sigW*beta + n*((lambda.*beta.*pbeta0)./(abeta+epsr))));  % if Q'(beta)<tau/2
 beta_int=beta;
end;


r = y- x*beta;

 
%%%% To compute effective number of parameters.

effno = trace((x'*x-sigW+n*diag((lambda.*pbeta0)./(abeta+epsr)))^(-1)*x'*x);

rss = sum(r.^2); %% Residual sum of squares.

abeta=abs(beta);
pbeta0=(abeta<=lambda)+((a*lambda-abeta)./((a-1)*lambda)).*((abeta>lambda).*(abeta<a*lambda));
delta0 = abs(x'*(x*beta-y) -sigW*beta + n*(lambda.*sign(beta)).*pbeta0);  % if Q'(beta)<tau
 
beta(delta0>=tau) = 0;

d0=d-sum(delta0>=tau);



t1=inv(x'*x-sigW+n*diag((lambda.*pbeta0)./(abeta+epsr)));
t2=x'*diag(r.^2)*x*n/(n-d0);
beta_std=sqrt(diag(t1*t2*t1));

 
 

 

 

