function [beta_est gamma_est group_est] = ...
    iterRF(X, Z, Y, groups, Gmat, pena, lam, maxiter)

warning off all
if nargin < 9
    maxiter = 30;
end

ngroups = length(groups{1});% number of subjects
p=length(groups);% 10 random effects
dm=p*ngroups;

[nsample d]= size(X); % d=8 fixed effects

% [beta_est]=fixest(X, Z,...
%                            Y, groups, Gmat, pena, lam);

[temp1, temp0]= randest(X, Z, Y, groups, Gmat, pena,lam);

Ridini = find(temp0(1,:)); % the initial estimate of random effects

Rid_expand = zeros(p*ngroups,1);
for i=1:length(Ridini), Rid_expand(groups{Ridini(i)})=1; end

Gmat_new = 1*eye(sum(Rid_expand));

[beta_est]=fixest(X, Z(:,Rid_expand==1),...
                           Y, groups(Ridini), Gmat_new, pena);
Fid_ini = beta_est(2,:)~=0;

[gamma_est, group_est]= randest(X(:,Fid_ini), Z, Y, groups, Gmat, pena);



 
