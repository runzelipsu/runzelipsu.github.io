% rhols.m
% 
% Solves  min_beta  1/2 ||y - X beta||_2^2 + lambda rho(|beta|)
%

function [betap w]= rhols(X, y, groups,lambda, pena, maxiter, inivec)

sica = @(x, a) a*(a + 1)./(a + abs(x)).^2;

[n, p] = size(X);

if (nargin < 5) pena = lambda; end
if (nargin < 6) maxiter = 10; end
if (nargin < 7) 
    if (p <= ceil(log(n))*n)
        inivec = inv(X'*X + 1e-10*eye(p))*X'*y;
    else
        inivec = X'*inv(X*X' + 1e-10*eye(n))*y;
    end
end


rhoprime = @(x) sica(x, pena);



betap = inivec;

for k = 1:maxiter
    for i=1:length(groups)
    betap_g(i) = norm(betap(groups{i}),2);
    w1(groups{i})=betap_g(i)*ones(size(groups{i}));
    end
    w2 = rhoprime(w1);
    w = w2'.*betap./w1';
    w(w==NaN)=0;
    betap = wlasso(X, y, lambda, w);
end
w=rhoprime(betap);

for i=1:length(groups)
    betap_g(i) = norm(betap(groups{i}),2);
end
