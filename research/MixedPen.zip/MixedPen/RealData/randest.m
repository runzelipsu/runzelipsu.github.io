function [gammaest_new groupest]= randest(X, Z, Y, groups, Gmat, pena, lambdas, maxiter)
warning off all
if nargin < 8
    maxiter = 30;
end

ngroups = length(groups{1});% number of subjects
p=length(groups);% 10 random effects
dm=p*ngroups;

[nsample d]= size(X); % d=8 fixed effects
Zstack=Z(:,1:p);

for k=1:(ngroups-1)
    Zstack = Zstack + Z(:,(k*p+1):(k*p+p));
end

XX = [X Zstack];


%%% First calculate the design matrix
    Pxmat = speye(nsample)-X/(X'*X)*X';
%    Pxmat_val = speye(length(Yval))-Xval/(Xval'*Xval)*Xval';

    SigmaZ = (Z'*Pxmat'*Z)/nsample;
    QmatZ = (Z'*Pxmat'*Y)/nsample;
    
    Gmat = Gmat*nsample;
    
    % compute least-square estimate
    gammaest = (SigmaZ+inv(Gmat))\(QmatZ);
    
    if nargin < 7
    lammax= 0.1*max(abs(XX'*Y))/nsample;
    lammin = 1e-4*lammax;
    lambdas = 0.01*((10:-1:1)/10).^2*lammax;
    end
    
     for kk=1:length(lambdas)
        lambda = lambdas(kk);
        clear idcount
        [W]=wglassoSCAD(SigmaZ,QmatZ,Gmat,groups,lambda, pena, maxiter);
        
        gammahat(kk,:) = W;
        groupsel = find(W2norms(W,groups)>0);
        idcount(kk)=(length(groupsel)<nsample/ngroups);
        groupsel_id(kk,:)=W2norms(W,groups)>0;
        id_W0 = abs(W)>0;
        id_W(kk,:) = id_W0;
        
        gammaest1 = zeros(length(id_W0'),1);  
        if ~isempty(groupsel)
           gammaest0 = (SigmaZ(id_W0,id_W0)+inv(Gmat(id_W0,id_W0)))\QmatZ(id_W0,:);
           gammaest1(id_W0) = gammaest0;
        end
        
        %mu=mean(Zval*gammaest1);
   
        sig2hat = (Y - Z*gammahat(kk,:)'+mean(Z*gammahat(kk,:)'))'*Pxmat*(Y - Z*gammahat(kk,:)'+mean(Z*gammahat(kk,:)'))/rank(Pxmat);
        loglik = (Y - Z*gammahat(kk,:)'+mean(Z*gammahat(kk,:)'))'*(Y - Z*gammahat(kk,:)'+mean(Z*gammahat(kk,:)'));


         BIC(kk) = loglik + log(nsample)*ngroups*length(find(groupsel_id(kk,:)));
         AIC(kk) = loglik + 2*ngroups*length(find(groupsel_id(kk,:)));
         

    end
    
    [temp id_BIC]=min(BIC);
    [temp id_AIC]=min(AIC);
    
%     [temp,I] = find(bic==min(bic(idcount)),1,'first');
%    
%     [temp,I2] = find(aic==min(aic(idcount)),1,'first');
    
    groupest(1,:) = squeeze(groupsel_id(id_AIC,:));
    groupest(2,:) = squeeze(groupsel_id(id_BIC,:));
    
    gammaest_new(1,:) = gammahat(id_AIC,:)';
    gammaest_new(2,:) = gammahat(id_BIC,:)';