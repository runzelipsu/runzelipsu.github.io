% rhols.m
% 
% Solves  min_beta  1/2 ||y - X beta||_2^2 + lambda rho(|beta|)
%

function [betap betap_g w]= scadls(X, y, ridge0, groups, lambda, a, maxiter, inivec)

scad = @(lam, x, a) ((abs(x) <= lam) + max(a*lam - abs(x), 0).*(abs(x) > lam)/((a-1)*lam));

[n, p] = size(X);

if (nargin < 7) maxiter = 10; end
if (nargin < 8) 
    %if (p <= ceil(log(n))*n)
        inivec = inv(X'*X + ridge0)*X'*y;
    %else
    %    inivec = X'*inv(X*X' + 1e-10*eye(n))*y;
    %end
end

rhoprime = @(x) scad(lambda, x, a);

betap = inivec;

for k = 1:maxiter
    for i=1:length(groups)
    betap_g(i) = norm(betap(groups{i}),2);
    w1(groups{i})=betap_g(i)*ones(size(groups{i}));
    end
    w2 = rhoprime(w1);
    w = w2'.*betap./w1';
    w(w==NaN)=0;
    betap = wlasso(X, y, ridge0, lambda, w);
end
w=rhoprime(betap);

for i=1:length(groups)
    betap_g(i) = norm(betap(groups{i}),2);
end