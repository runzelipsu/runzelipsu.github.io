clear all
close all
format long
warning off all
[yall,TC,nI]=cd4;


iduse = 1:length(yall);
Y0 = yall(iduse,end);

XX = yall(iduse,3:(end-1));
nsample = length(iduse);
subject_id = yall(iduse,2);
temp = unique(subject_id);
nsubject = length(temp);

mm=2;
norder=4; %cubic spline
knots = [zeros(1,norder-1) 0:(1/mm):1 ones(1,norder-1)]; 
Bbasis = bspline_basismatrix(norder,quantile(sort(XX(:,1)),knots),XX(:,1));

X0 =[Bbasis XX(:,2:4) Bbasis.*(XX(:,4)*ones(1,mm+3)) XX(:,2).*XX(:,3) XX(:,2).*XX(:,4) XX(:,3).*XX(:,4)];

% X0 = [ones(nsample,1) XX(:,1) XX(:,1).^2 XX(:,1).^3 XX(:,2:4) XX(:,1).*XX(:,4) XX(:,1).^2.*XX(:,4) XX(:,1).^2.*XX(:,4)...
%      XX(:,2).*XX(:,3) XX(:,2).*XX(:,4) XX(:,3).*XX(:,4)];
% X0=(X0 - ones(length(X0(:,1)),1)*mean(X0));
 
X = (X0 - ones(length(X0(:,1)),1)*mean(X0));%centerlized, no intercept

Y=Y0-mean(Y0);
rank(X)
[~, d]= size(X0); % d is the number of fixed effects
p = 17; % from 1 to 7 are the random effects 


groups = cell(p,1);
for i=1:p, groups{i} = (0:(nsubject-1))*p+i; end

id_rand = [1:17];


Z=[];
for i=1:nsubject
    Z= blkdiag(Z,[ones(sum(subject_id==i),1) X(subject_id==i,:)]);
end
Gmat = log(nsample)*speye(length(Z(1,:)));


[beta_est_SCAD gamma_est_scad groupest_scad]= ...
    iterRF(X, Z, Y, groups, Gmat,'SCAD',0.8); % full iteration

                       
%save CD4results.mat 
groupsest_aic = groupest_scad(1,:);
groupsest_bic = groupest_scad(2,:);



boxplot(randcoef(groupsest_aic,:)','labels',{'b1(t)x3','b2(t)x3',...
    'b3(t)x3','b4(t)x3','b5(t)x3','x1x3','x2x3'})

std(randcoef(groupsest_aic,:)')

std(Y-Z*gamma_est_scad(1,:)'-X*beta_est_SCAD(2,:)')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
