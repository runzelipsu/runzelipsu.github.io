function norms = W2normsmat(W,groups);
norms = zeros(length(W),length(groups));
for i=1:length(groups)
    norms(:,i) = sqrt(sum(W(:,groups{i}).^2,2));
end