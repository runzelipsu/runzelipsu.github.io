% wlasso.m
% 
% Solves  min_beta  1/2 ||y - X beta||_2^2 + lambda ||w.*beta||_1
%

function betap = wlasso(X, y, ridge0, lambda, w)

[n, p] = size(X);
thresh = 1e-6;

ind1 = find(abs(w) > thresh);
ind2 = setdiff(1:p, ind1);

w1 = w(ind1);
X1 = X(:, ind1);
X2 = X(:, ind2);
d1 = length(ind1);
d2 = length(ind2);
D1 = sparse(1:d1, 1:d1, 1./w1);

betap = zeros(p, 1);

if d1 == 0
    %if (d2 <= ceil(log(n))*n)
        betap = inv(X2'*X2 + ridge0(ind2,ind2))*X2'*y;
    %else
    %    betap = X2'*inv(X2*X2' + 1e-10*eye(n))*y;
    %end
else
    %if (d2 <= ceil(log(n))*n)
        H = X2*inv(X2'*X2 + ridge0(ind2,ind2))*X2';
    %else
    %    H = X2*X2'*inv(X2*X2'+ 1e-10*eye(n));
    %end

    y1 = y - H*y;
    X1new = X1 - H*X1; 
    betap1 = D1*rlasso(X1new*D1, y1, ridge0, lambda);

    y2 = y - X1*betap1;
    %if (d2 <= ceil(log(n))*n)
        betap2 = inv(X2'*X2 + ridge0(ind2,ind2))*X2'*y2;
    %else
    %    betap2 = X2'*inv(X2*X2' + 1e-10*eye(n))*y2;
    %end

    betap(ind1, 1) = betap1;
    betap(ind2, 1) = betap2;
end
