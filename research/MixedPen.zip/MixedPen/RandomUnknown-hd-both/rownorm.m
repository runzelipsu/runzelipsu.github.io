function norms = rownorm(W,p);
if nargin < 2
   p = 2;
end
[n m]=size(W);
norms = zeros(n,1);
for i=1:n
    norms(i) = norm(W(i,:),p);
end