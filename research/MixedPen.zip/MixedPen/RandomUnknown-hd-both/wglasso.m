function [W]=wglasso(SigmaZ,QmatZ,Gmat,groups,lambda)

alpha0 = 1e-4;

optparam.tol = 1e-16;
optparam.kmax = 100;
optparam.tol_df = 1e-20;
optparam.display= 0;
barriers = 10.^[0:.5:4];
maxiter = 20;
 
addpath utilities

gammaest = (SigmaZ + inv(Gmat))\QmatZ;
sica = @(x, a) a*(a + 1)./(a + abs(x)).^2;

for k=1:maxiter
    
    gammagroup = W2norms(gammaest,groups);
    
    Zweight = zeros(size(gammaest));
    for i=1:length(groups)
        Zweight(groups{i}) = gammagroup(i)*ones(length(groups{i}),1);
    end
    
    Dweight = sparse(1:length(Zweight),1:length(Zweight),1./sica(Zweight,lambda+(lambda^2+2*lambda)));
    SigmaZ_new = Dweight*SigmaZ*Dweight;
    QmatZ_new = Dweight*QmatZ;
    
    for ibar = 1:length(barriers)
        [W] = minimize_newton(gammaest,@grouplasso,optparam,SigmaZ_new,QmatZ_new,groups,lambda,alpha0/barriers(ibar));
    end
    
    gammaest = Dweight*W;
end
W=gammaest.*(abs(gammaest)>thresh);