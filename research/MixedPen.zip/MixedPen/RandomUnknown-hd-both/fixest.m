function [beta_final_est]=fixest(X, Z, ni, Y, groups, Gmat, pena, maxiter)
warning off all
if nargin < 9
    maxiter = 15;
end

ngroups = length(groups{1});% number of subjects
p=length(groups);% 10 random effects
dm=p*ngroups;
[nsample d]= size(X); % d=8 fixed effects

Zstack=Z(:,1:p);
for k=1:(ngroups-1)
    Zstack = Zstack + Z(:,(k*p+1):(k*p+p));
end

XX = [X Zstack];

groupsfix=cell(d,1);
for i=1:d, groupsfix{i}=i; end 
NUMS = repmat((1:ngroups),ni,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55
%% estimate fixed effects
    Pzmat = inv(speye(nsample)+Z*Gmat*Z');
    SigmaX = (X'*Pzmat*X)/nsample;
    QmatX = (X'*Pzmat'*Y)/nsample;
    
    % compute least-square estimate
    gammaest = (SigmaX)\QmatX;
    
    lammax=10*max(abs(X'*Pzmat*Y))/nsample;
    lambdas = ((25:-1:1)/25).^2*lammax;
    
    for kk=1:length(lambdas)
        lambda = lambdas(kk);
        [W]=wglassoSCAD2(SigmaX,QmatX,groupsfix,lambda,pena,maxiter);
        
        betahat(kk,:) = W;
        idsel = find(abs(W)>0);
    
        Resid = Y-X*reshape(W,size(X,2),1);
        Resid = Resid - mean(Resid);
        loglik = Resid'*Pzmat*Resid;
        aic(kk) =   loglik + (length(idsel)+ngroups*p)*2;
        bic(kk) =   loglik + (length(idsel)+ngroups*p)*log(nsample);
    end
   [temp,I] = find(bic==min(bic),1,'last');
   [temp,I2] = find(aic==min(aic),1,'last');
    
    beta_final_est(2,:)=squeeze(betahat(I,:));
    %idest(2,:) = find(beta_final_est(2,:));
    
    beta_final_est(1,:)=squeeze(betahat(I2,:));
    %idest(1,:) = find(beta_final_est(1,:));
    
