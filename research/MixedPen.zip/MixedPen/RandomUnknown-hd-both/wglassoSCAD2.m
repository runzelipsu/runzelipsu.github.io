function [W]=wglassoSCAD2(SigmaZ,QmatZ,groups,lambda,pena, maxiter)

alpha0 = 1e-4;
optparam.tol = 1e-16;
optparam.kmax = 100;
optparam.tol_df = 1e-20;
optparam.display= 0;
barriers = 10.^[0:.8:4];
a_scad = 3.7;
thresh = 1e-4;

addpath utilities

gammaest = (SigmaZ+1e-8*eye(length(QmatZ)))\QmatZ;

scad = @(lam, x) ((abs(x) <= lam) + max(3.7*lam - abs(x), 0).*(abs(x) > lam)/(2.7*lam));
sica = @(x, a) a*(a + 1)./(a + abs(x)).^2;
mcp = @(lam, x) max(3.7*lam - abs(x), 0)/(3.7*lam);
if strcmp(pena, 'SCAD')
    rhoprime = @(x) scad(lambda, x);
elseif strcmp(pena, 'MCP')
    rhoprime = @(x) mcp(lambda, x);
elseif strcmp(pena, 'Lasso')
    rhoprime = @(x) ones(size(x));
    maxiter = 1;
else
    rhoprime = @(x) sica(x, pena);
end



for k=1:maxiter
    
    gammagroup = W2norms(gammaest,groups);
    
    Zweight = zeros(size(gammaest));
    for i=1:length(groups)
        Zweight(groups{i}) = gammagroup(i)*ones(length(groups{i}),1);
    end
    
    Zweight0 = rhoprime(Zweight);
    id1 = find(Zweight0>thresh)';
    id2 = setdiff(1:length(Zweight0),id1)';
    d1 = length(id1);
    d2 = length(id2);
    
   
    if d1 == 0;
        W = SigmaZ\QmatZ;
    else
%         Ginv1 = inv(Gmat(id1,id1));
%         Ginv2 = inv(Gmat(id2,id2));
        
        gammaest1 = (SigmaZ(id2,id2)+1e-8*eye(length(id2)))\QmatZ(id2,:);
        
        Dweight = sparse(1:d1,1:d1,1./Zweight0(id1));
        SigmaZ_new = Dweight*(SigmaZ(id1,id1))*Dweight;
        QmatZ_new = Dweight*(QmatZ(id1)-SigmaZ(id1,id2)*gammaest1);
        
        temp = ones(1,length(Zweight0));
        temp(id2) = 0;
        groupid = cumsum(temp);
        
        groups_new = cell(length(groups),1);
        for j = 1:length(groups)
        groups_new{j} = groupid(intersect(groups{j},id1));
        end
        
        gammaest0 = (SigmaZ_new+1e-8*eye(length(QmatZ_new)))\QmatZ_new;
        for ibar = 1:length(barriers)
            %ibar
        [gammaest0] =  minimize_newton(gammaest0,@grouplasso,optparam,SigmaZ_new,QmatZ_new,groups_new,lambda,alpha0/barriers(ibar));
        end
        gammaest0=gammaest0.*(abs(gammaest0)>thresh);
        W(id1) = Dweight*gammaest0;
        gammaest1 = (SigmaZ(id2,id2)+1e-8*eye(length(id2)))\(QmatZ(id2,:) - SigmaZ(id2,id1)*Dweight*gammaest0); 
        
        W(id2) = gammaest1;
        
    end
   
   if norm(reshape(gammaest, size(W))-W)<1e-4
      gammaest = W;
      break
    end
    gammaest = W;
end
