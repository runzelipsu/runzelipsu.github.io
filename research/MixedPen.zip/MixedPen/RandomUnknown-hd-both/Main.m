% mixed effects model
% y_i = X_i\beta + Z_i\gamma_i + \eps_i
% y_i : response
% \beta : fixed effects
% \gamma_i : random effects
% \eps_i : noise


close all
clear all
format long

randn('state',100);
rand('state',100);

warning off all


p= 6; % # of random effects
d = 30; % # of fixed effects
pobs= p;
ngroups= 30;% number of subjects

dm= p*ngroups;
ni=5;% # of observations each group

gfactor = kron(1:ngroups,ones(1,ni))'; % index showing which subject the obs is from
maxiter0 = 2;
maxiter = 30;

rep=2; % repeat 200 times

id_fix = [1,2]; % 2 true fixed effects
id_rand = [1,2,3]; % 3 true random effects

beta = zeros(d,1);
beta(id_fix) = [1 1]'; % fixed effects coefficients vector



% group index for radom effects
groups = cell(pobs,1);
for i=1:pobs, groups{i} = (0:(ngroups-1))*pobs+i; end


NUMS = repmat((1:ngroups),ni,1);
gamma_oracle=zeros(rep,dm); % oracle estimate of random effects coefficients vector
gamma_oracle2=zeros(rep,dm);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

rho =0.5; % correlation between random effects

% we can calculate R and G by using formulae
Gmat_block = zeros(pobs);
Gmat_block(id_rand,id_rand) = [9 4.8 0.6; 4.8 4 1; 0.6 1 1];

Gmat_true=[];
for i=1:ngroups
    Gmat_true = blkdiag(Gmat_true, Gmat_block);
end
Gmat_true = ni*ngroups*Gmat_true;

Rmat_true = eye(ni*ngroups);


beta_oracle_est = zeros(rep,d);
gamma_oracle_est = zeros(rep,dm);

sigma = 1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%Simulation loop begins

tt=1;
for tt=1:rep
    tt
    
%% fixed effects design
X = -2+4*rand(ngroups*ni,d);

    
%random effects
    Z=[]; Zstack=[];
    for i=1:ngroups
        mat=[ones(ni,1) -2+4*rand(ni,p-1)];
        Z=blkdiag(Z,mat(:,1:pobs));
        Zstack=[Zstack;mat(:,1:pobs)];
    end
    
    XX = [X Zstack]; % full design matrix combing fixed and random effects
    
    % random effects coefficients vector
    gamma0 = zeros(pobs*ngroups,1);
    randeffect = randn(ngroups,length(id_rand))*Gmat_block(id_rand, id_rand)^0.5;
    gamma0(groups{1})=randeffect(:,1) ;
    gamma0(groups{2})=randeffect(:,2) ;
    gamma0(groups{3}) = randeffect(:,3) ;
    
    Y= X*beta+Z*gamma0+1*randn(ni*ngroups,1); % now generate the response vector
    
    gamma0_mat(:,tt)=gamma0;
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% estimation of random effects
   % initial estimate 
   Rmat = eye(ni*ngroups);
   Gmat = 3*log(ni*ngroups)*eye(length(Z(1,:)));
   
   [gamma_est_scad(tt,:,:) group_est_scad(tt,:,:)]= randest(X, Z, Y, groups, Gmat, 'SCAD');
   
   %%% estimation of fixed effects
   [beta_est_scad(tt,:,:)]=fixest(X, Z, ni, Y, groups, Gmat, 'SCAD');
end

