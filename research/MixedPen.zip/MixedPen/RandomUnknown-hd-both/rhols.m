% rhols.m
% 
% Solves  min_beta  1/2 ||y - X beta||_2^2 + lambda rho(|beta|)
%

function [betap w]= rhols(X, y, lambda, pena, maxiter, inivec)

sica = @(x, a) a*(a + 1)./(a + abs(x)).^2;
scad = @(lam, x) ((abs(x) <= lam) + max(3.7*lam - abs(x), 0).*(abs(x) > lam)/(2.7*lam));
mcp = @(lam, x) max(3.7*lam - abs(x), 0)/(3.7*lam);

[n, p] = size(X);

if (nargin < 5) maxiter = 10; end
if (nargin < 6) 
    if (p <= ceil(log(n))*n)
        inivec = inv(X'*X + 1e-10*eye(p))*X'*y;
    else
        inivec = X'*inv(X*X' + 1e-10*eye(n))*y;
    end
end

if strcmp(pena, 'SCAD')
    rhoprime = @(x) scad(lambda, x);
elseif strcmp(pena, 'MCP')
    rhoprime = @(x) mcp(lambda, x);
elseif strcmp(pena, 'Lasso')
    rhoprime = @(x) ones(size(x));
    maxiter = 1;
else
    rhoprime = @(x) sica(x, pena);
end


betap = inivec;

for k = 1:maxiter
    w = rhoprime(betap);
    betap = wlasso(X, y, lambda, w);
end
w=rhoprime(betap);
