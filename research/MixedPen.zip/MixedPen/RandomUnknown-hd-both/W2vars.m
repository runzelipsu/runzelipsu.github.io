function norms = W2vars(W,groups);
norms = zeros(length(groups),1);
for i=1:length(groups)
    norms(i) = mean(W(groups{i}).^2);
end